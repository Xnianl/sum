﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.sum1Btn = new System.Windows.Forms.Button();
            this.numBox1 = new System.Windows.Forms.TextBox();
            this.numBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.resultBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // sum1Btn
            // 
            this.sum1Btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sum1Btn.ForeColor = System.Drawing.Color.Red;
            this.sum1Btn.Location = new System.Drawing.Point(127, 5);
            this.sum1Btn.Name = "sum1Btn";
            this.sum1Btn.Size = new System.Drawing.Size(46, 30);
            this.sum1Btn.TabIndex = 0;
            this.sum1Btn.Text = "+";
            this.sum1Btn.UseVisualStyleBackColor = true;
            this.sum1Btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // numBox1
            // 
            this.numBox1.Location = new System.Drawing.Point(21, 12);
            this.numBox1.Name = "numBox1";
            this.numBox1.Size = new System.Drawing.Size(100, 20);
            this.numBox1.TabIndex = 1;
            this.numBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // numBox2
            // 
            this.numBox2.Location = new System.Drawing.Point(179, 12);
            this.numBox2.Name = "numBox2";
            this.numBox2.Size = new System.Drawing.Size(100, 20);
            this.numBox2.TabIndex = 2;
            this.numBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(285, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "=";
            // 
            // resultBox1
            // 
            this.resultBox1.Location = new System.Drawing.Point(310, 12);
            this.resultBox1.Name = "resultBox1";
            this.resultBox1.Size = new System.Drawing.Size(100, 20);
            this.resultBox1.TabIndex = 4;
            this.resultBox1.TextChanged += new System.EventHandler(this.resultBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.resultBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numBox2);
            this.Controls.Add(this.numBox1);
            this.Controls.Add(this.sum1Btn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button sum1Btn;
        private System.Windows.Forms.TextBox numBox1;
        private System.Windows.Forms.TextBox numBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox resultBox1;
    }
}

