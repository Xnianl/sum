﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // varaibles
            int number1 = 0; /* assignment */
            number1 = Convert.ToInt32(numBox1.Text); /* use function ToInt32 of class Convert to covert String in number */

            int number2 = 0; /* assignment */
            number2 = Convert.ToInt32(numBox2.Text); /* use function ToInt32 of class Convert to covert String in number */

            int number3 = 0; /* assignment */
            number3 = number1 + number2; /* expression */

            resultBox1.Text = Convert.ToString(number3); /* use function ToString of class Convert to covert number in String */

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void resultBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
